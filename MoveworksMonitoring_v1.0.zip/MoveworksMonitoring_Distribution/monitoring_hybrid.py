#!/usr/bin/env python3
"""
FINRA Moveworks Monitoring System - FAST DEBUG VERSION
Optimized for rapid debugging - gets to chat navigation in ~30 seconds instead of 5 minutes
"""

import json
import csv
import time
import smtplib
from datetime import datetime
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from selenium.common.exceptions import TimeoutException, WebDriverException
from selenium.webdriver.common.keys import Keys
import os

class SmartResourceChecker:
    """
    Smart resource checking system extracted from moveworks_monitor.py
    Provides intelligent system resource monitoring with adaptive thresholds
    """
    
    def __init__(self):
        self.psutil_available = self._check_psutil_availability()
        
    def _check_psutil_availability(self):
        """Check if psutil is available for resource monitoring"""
        try:
            import psutil
            return True
        except ImportError:
            print("psutil not available - resource checking will be limited")
            return False
    
    def check_system_resources(self):
        """
        Enhanced system resource checking with detailed reporting
        
        Returns:
            bool: True if system resources are sufficient, False if overloaded
        """
        if not self.psutil_available:
            print("psutil not available - proceeding without resource check")
            return True
            
        try:
            import psutil
            
            # Get current system metrics
            cpu_percent = psutil.cpu_percent(interval=1)
            memory_percent = psutil.virtual_memory().percent
            available_memory_gb = psutil.virtual_memory().available / (1024**3)

            print(f"System resources - CPU: {cpu_percent}%, Memory: {memory_percent}% ({available_memory_gb:.1f}GB available)")
            
            # ADAPTIVE THRESHOLDS based on available memory
            if available_memory_gb < 2:  # Less than 2GB available
                cpu_threshold = 70    # More strict when memory is low
                memory_threshold = 80
                print("Low memory detected - using strict resource thresholds")
            else:
                cpu_threshold = 80    # Normal thresholds
                memory_threshold = 85
                print("Sufficient memory - using normal resource thresholds")

            # Check if system is overloaded
            if cpu_percent > cpu_threshold or memory_percent > memory_threshold:
                print(f"System overloaded (CPU: {cpu_percent}% > {cpu_threshold}% OR Memory: {memory_percent}% > {memory_threshold}%)")
                print("Will retry in 5 minutes when system load decreases...")
                return False
            
            print("System resources sufficient for monitoring")
            return True
        
        except Exception as e:
            print(f"Resource check failed: {e} - proceeding anyway")
            return True
    
    def wait_for_resources(self, max_wait_minutes=10, check_interval_seconds=30):
        """
        Wait for system resources to become available
        """
        print(f"Waiting for system resources (max {max_wait_minutes} minutes)...")
        
        max_checks = (max_wait_minutes * 60) // check_interval_seconds
        
        for check in range(max_checks):
            if self.check_system_resources():
                print(f"Resources available after {check * check_interval_seconds} seconds")
                return True
            
            remaining_checks = max_checks - check - 1
            remaining_time = remaining_checks * check_interval_seconds
            print(f"Resources still insufficient, checking again in {check_interval_seconds}s ({remaining_time}s remaining)")
            
            time.sleep(check_interval_seconds)
        
        print(f"Timeout: Resources did not become available within {max_wait_minutes} minutes")
        return False

class MoveworksMonitor:
    def __init__(self, config_file='config.json'):
        self.config = self.load_config(config_file)
        self.csv_file = 'moveworks_status.csv'
        self.driver = None
        self.previous_status = None
        self.resource_checker = SmartResourceChecker()  # Add resource checker
        self.init_csv_file()

    def load_config(self, config_file):
        default_config = {
            "teams_email": "your_email@finra.org",
            "teams_password": "your_password_here",
            "moveworks_bot_name": "Moveworks",
            "alert_email": "your_email@finra.org",
            "smtp_server": "smtp.office365.com",
            "smtp_port": 587,
            "check_interval_hours": 2,
            "test_message": "health check",
            "timeout_seconds": 30,
            "chromedriver_path": "C:\\Windows\\System32\\chromedriver.exe",
            
            # SINGLE SWITCH: Change this ONE line to go from testing to production
            #"notification_target": "Rodriguez, Fabricio",  # TESTING MODE
            "notification_target": "Real MW Core",       # PRODUCTION MODE (uncomment when ready)
            
            "enable_teams_notifications": True
        }

        try:
            if os.path.exists(config_file):
                with open(config_file, 'r') as f:
                    user_config = json.load(f)
                    default_config.update(user_config)
            else:
                with open(config_file, 'w') as f:
                    json.dump(default_config, f, indent=4)
                print(f"Config file '{config_file}' created with default settings.")
        except Exception as e:
            print(f"Config error: {e}. Using defaults.")

        return default_config

    def init_csv_file(self):
        if not os.path.exists(self.csv_file):
            with open(self.csv_file, 'w', newline='') as file:
                writer = csv.writer(file)
                writer.writerow(['timestamp', 'status', 'response_time_ms', 'details'])

    def setup_headless_browser(self):
        try:
            if not self.resource_checker.check_system_resources():
                print("System resources insufficient, waiting...")
                if not self.resource_checker.wait_for_resources(max_wait_minutes=5):
                    print("Proceeding with limited resources")
            
            chrome_options = Options()
            chrome_options.add_argument("--headless=new")
            chrome_options.add_argument("--no-sandbox")
            chrome_options.add_argument("--disable-dev-shm-usage")
            chrome_options.add_argument("--disable-gpu")
            chrome_options.add_argument("--disable-extensions")
            chrome_options.add_argument("--disable-plugins")
            chrome_options.add_argument("--disable-images")
            chrome_options.add_argument("--disable-default-apps")
            chrome_options.add_argument("--disable-popup-blocking")
            chrome_options.add_argument("--disable-translate")
            chrome_options.add_argument("--disable-background-timer-throttling")
            chrome_options.add_argument("--disable-renderer-backgrounding")
            chrome_options.add_argument("--disable-backgrounding-occluded-windows")
            chrome_options.add_argument("--disable-features=TranslateUI")
            chrome_options.add_argument("--disable-ipc-flooding-protection")
            
            # Essential stealth (minimal)
            chrome_options.add_argument("--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.7204.184 Safari/537.36")
            chrome_options.add_argument("--disable-blink-features=AutomationControlled")
            chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])
            chrome_options.add_experimental_option('useAutomationExtension', False)
            
            # FAST prefs - block everything slow
            chrome_options.add_experimental_option("prefs", {
                "profile.default_content_setting_values.notifications": 2,  # Block
                "profile.default_content_settings.popups": 2,  # Block
                "profile.managed_default_content_settings.images": 2,  # Block images
                "profile.default_content_setting_values.media_stream": 2,  # Block media
                "profile.default_content_setting_values.plugins": 2,  # Block plugins
                "profile.default_content_setting_values.geolocation": 2,  # Block location
            })
            
            chrome_options.add_argument("--disable-features=VizDisplayCompositor")
            chrome_options.add_argument("--disable-ipc-flooding-protection")

            service = Service(executable_path=self.config['chromedriver_path'])
            self.driver = webdriver.Chrome(service=service, options=chrome_options)
            self.driver.set_page_load_timeout(10)  # Fast timeout for debugging
            self.driver.implicitly_wait(3)  # Reduced wait time
            
            print("✅ FAST DEBUG: Browser ready in ~5 seconds")
            
            # Remove automation fingerprints
            stealth_js = """
                Object.defineProperty(navigator, 'webdriver', {get: () => undefined});
                delete window.cdc_adoQpoasnfa76pfcZLmcfl_Array;
                delete window.cdc_adoQpoasnfa76pfcZLmcfl_Promise;
                delete window.cdc_adoQpoasnfa76pfcZLmcfl_Symbol;
                window.chrome = {
                    runtime: {},
                    loadTimes: function() {},
                    csi: function() {},
                    app: {}
                };
            """
            self.driver.execute_script(stealth_js)
            
            # Override user agent via CDP
            try:
                self.driver.execute_cdp_cmd('Network.setUserAgentOverride', {
                    "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.7204.184 Safari/537.36"
                })
            except:
                pass
            
            # Set visible window for testing
            self.driver.set_window_position(100, 100)
            self.driver.set_window_size(1400, 900)
            print("Browser window is now VISIBLE - you can watch the process!")
            
            return True
        except Exception as e:
            print(f"Browser setup failed: {e}")
            return False

    def login_to_teams(self):
        try:
            print("Starting Teams login...")
            self.driver.get('https://teams.microsoft.com/v2/')
            time.sleep(1)
            
            if "unsupported-browser" in self.driver.current_url:
                print("Unsupported browser error detected")
                return False
            
            print("Step 1: Entering email...")
            email_selectors = [
                (By.NAME, "loginfmt"),
                (By.ID, "i0116"),
                (By.XPATH, "//input[@type='email']"),
                (By.CSS_SELECTOR, "input[type='email']")
            ]
            
            email_input = None
            for selector_type, selector_value in email_selectors:
                try:
                    email_input = WebDriverWait(self.driver, 5).until(
                        EC.element_to_be_clickable((selector_type, selector_value))
                    )
                    break
                except TimeoutException:
                    continue
                    
            if email_input:
                email_input.clear()
                email_input.send_keys(self.config["teams_email"])
                email_input.send_keys(Keys.ENTER)
                print("Email submitted")
            else:
                print("No email field found - might already be logged in")
            
            time.sleep(2)
            
            print("Step 2: Entering password...")
            password_selectors = [
                (By.NAME, "passwd"),
                (By.ID, "i0118"),
                (By.XPATH, "//input[@type='password']"),
                (By.CSS_SELECTOR, "input[type='password']")
            ]
            
            password_input = None
            for selector_type, selector_value in password_selectors:
                try:
                    password_input = WebDriverWait(self.driver, 5).until(
                        EC.element_to_be_clickable((selector_type, selector_value))
                    )
                    break
                except TimeoutException:
                    continue
                    
            if password_input:
                password_input.clear()
                password_input.send_keys(self.config["teams_password"])
                password_input.send_keys(Keys.ENTER)
                print("Password submitted")
            else:
                print("No password field found - might already be logged in")
            
            time.sleep(3)
            
            print("Step 3: Handling stay signed in...")
            try:
                stay_button = WebDriverWait(self.driver, 3).until(
                    EC.element_to_be_clickable((By.ID, "idSIButton9"))
                )
                stay_button.click()
                print("Clicked 'Stay signed in'")
            except TimeoutException:
                print("No 'Stay signed in' prompt")
                
            print("Step 4: Waiting for Teams to load...")
            time.sleep(5)
            
            current_url = self.driver.current_url
            page_title = self.driver.title
            
            print(f"Final URL: {current_url}")
            print(f"Final title: {page_title}")
            
            if ("teams.microsoft.com" in current_url and 
                "unsupported-browser" not in current_url and
                ("Chat" in page_title or "Teams" in page_title)):
                print("Teams loaded successfully!")
                return True
            else:
                print("FAILED: Teams did not load properly")
                return False
                
        except Exception as e:
            print(f"Login failed: {e}")
            return False

    def find_moveworks_bot(self):
        print("Opening Moveworks from Apps section...")
        
        try:
            if self.open_from_apps_section():
                print("Successfully found Moveworks in Apps section")
                return True
            else:
                print("Failed to find Moveworks in Apps section")
                return False
            
        except Exception as e:
            print(f"Error finding Moveworks bot: {e}")
            return False

    def open_from_apps_section(self):
        """Open Moveworks from Apps section - COMPLETE automation.py logic"""
        print("Opening Moveworks from Apps section...")

        try:
            # Wait for Teams navigation to load
            time.sleep(3)
            
            # STEP 1: Find and click Apps button (from automation.py)
            apps_selectors = [
                "//button[@aria-label='Apps']",
                "//*[@data-tid='app-bar-item-apps']", 
                "//span[text()='Apps']//parent::button",
                "//button[contains(@aria-label, 'Apps')]",
                "//*[contains(@aria-label, 'Apps')]",
                "//button[text()='Apps']",
                "//*[text()='Apps' and (@role='button' or name()='button')]"
            ]

            apps_button = None
            for selector in apps_selectors:
                try:
                    apps_button = WebDriverWait(self.driver, 2).until(
                        EC.element_to_be_clickable((By.XPATH, selector))
                    )
                    print("Found Apps button")
                    break
                except TimeoutException:
                    continue

            if not apps_button:
                print("Apps button not found")
                return False

            apps_button.click()
            print("Apps section opened")
            time.sleep(2)

            # STEP 2: Find Moveworks (NOT Sandbox - we want production Moveworks)
            print("Searching for Moveworks...")
            
            # Look for production "Moveworks" (not "Moveworks Sandbox")
            moveworks_selectors = [
                "//*[text()='Moveworks' and not(contains(text(), 'Sandbox'))]//following::button[text()='Open'][1]",
                "//*[contains(text(), 'Moveworks') and not(contains(text(), 'Sandbox'))]//following::button[text()='Open'][1]",
                "//button[text()='Open' and preceding::*[text()='Moveworks' and not(contains(text(), 'Sandbox'))]]",
                "//*[text()='Moveworks']//ancestor::*//button[text()='Open']"
            ]

            moveworks_button = None
            for selector in moveworks_selectors:
                try:
                    moveworks_button = WebDriverWait(self.driver, 3).until(
                        EC.element_to_be_clickable((By.XPATH, selector))
                    )
                    print("Found Moveworks Open button")
                    break
                except TimeoutException:
                    continue

            if not moveworks_button:
                print("Moveworks Open button not found")
                return False

            # STEP 3: Click Moveworks Open button
            print("Clicking Moveworks Open button")
            moveworks_button.click()
            time.sleep(2)

            # STEP 4: Handle popup modal (CRITICAL - from automation.py)
            print("Waiting for popup modal...")
            
            popup_selectors = [
                "//*[contains(text(), \"Let's go\")]//following::button[text()='Open'][1]",
                "//*[contains(text(), 'How would you like to use this app')]//following::button[text()='Open'][1]",
                "//div[contains(@class, 'modal') or contains(@class, 'popup')]//button[text()='Open']",
                "//button[text()='Open' and (contains(@class, 'primary') or contains(@class, 'prominent'))]",
                "//button[text()='Open']"
            ]

            popup_button = None
            for selector in popup_selectors:
                try:
                    popup_button = WebDriverWait(self.driver, 3).until(
                        EC.element_to_be_clickable((By.XPATH, selector))
                    )
                    break
                except TimeoutException:
                    continue

            if popup_button:
                print("Found popup Open button")
                self.driver.execute_script("arguments[0].click();", popup_button)
                print("Popup Open button clicked")
                time.sleep(2)
            else:
                print("No popup found - continuing")

            # STEP 5: Wait for Moveworks interface to load
            print("Waiting for Moveworks interface...")
            time.sleep(3)

            # STEP 6: Check for iframe (from automation.py)
            iframe_switched = self.switch_to_moveworks_iframe()
            if iframe_switched:
                print("Switched to Moveworks iframe")
            else:
                print("No iframe detected")

            print("Moveworks interface ready")
            return True

        except Exception as e:
            print(f"Error opening from Apps: {e}")
            return False

    def switch_to_moveworks_iframe(self):
        """Check for Moveworks iframe and switch if needed (from automation.py)"""
        try:
            iframe_selectors = [
                "//iframe[@data-tid='hwc-iframe']",
                "//iframe[contains(@src, 'moveworks')]",
                "//iframe[contains(@title, 'Moveworks')]",
                "//iframe[@name='embedded-page-container']"
            ]
            
            for selector in iframe_selectors:
                try:
                    iframe = WebDriverWait(self.driver, 2).until(
                        EC.presence_of_element_located((By.XPATH, selector))
                    )
                    self.driver.switch_to.frame(iframe)
                    return True
                except TimeoutException:
                    continue
            return False
        except Exception:
            return False

    def send_message_automation_method(self, message_input, text):
        """Use the EXACT working method from automation.py"""
        try:
            # Focus and click (from automation.py approach)
            self.driver.execute_script("arguments[0].focus();", message_input)
            self.driver.execute_script("arguments[0].click();", message_input)
            time.sleep(0.2)
            
            # Clear any existing text (automation.py method)
            message_input.send_keys(Keys.CONTROL + "a")
            message_input.send_keys(Keys.DELETE)
            time.sleep(0.1)
            
            # Send the message (EXACT automation.py method)
            message_input.send_keys(text)
            message_input.send_keys(Keys.ENTER)
            
            print(f"Message sent using automation.py method: '{text}'")
            return True
            
        except Exception as e:
            print(f"Automation.py method failed: {e}")
            return False

    def check_for_moveworks_response_buttons(self):
        """Check for Moveworks response buttons to determine if bot is UP - OPTIMIZED VERSION"""
        try:
            print("Checking for Moveworks response buttons...")
            
            # Target button texts we're looking for
            target_buttons = [
                "Live Agent",
                "Start IT Live Chat", 
                "Create Ticket",
                "Live Agent/Create Ticket"
            ]
            
            found_buttons = []
            
            # OPTIMIZED: Use a single XPath to find all potential button elements
            try:
                # Find all clickable elements that might be buttons
                button_elements = self.driver.find_elements(By.XPATH, 
                    "//button | //div[@role='button'] | //span[contains(@class, 'button')] | //*[contains(@class, 'btn')]")
                
                for element in button_elements:
                    try:
                        if element.is_displayed():
                            button_text = element.text.strip()
                            # Check if this element contains any of our target button texts
                            for target in target_buttons:
                                if target in button_text and len(button_text) < 100:
                                    if button_text not in [btn[1] for btn in found_buttons]:
                                        found_buttons.append((element, button_text))
                                        print(f"Found Moveworks button: '{button_text}'")
                                        break
                    except:
                        continue
                        
            except Exception as e:
                print(f"Button search failed: {e}")
            
            # FALLBACK: If no buttons found with optimized search, try the old method but with timeout
            if not found_buttons:
                print("No buttons found with optimized search, trying fallback...")
                try:
                    # Quick fallback search with timeout
                    for target in target_buttons[:2]:  # Only check first 2 to avoid hanging
                        elements = self.driver.find_elements(By.XPATH, f"//*[contains(text(), '{target}')]")
                        for element in elements[:3]:  # Only check first 3 matches
                            try:
                                if element.is_displayed():
                                    button_text = element.text.strip()
                                    if button_text and len(button_text) < 50:
                                        found_buttons.append((element, button_text))
                                        print(f"Found Moveworks button (fallback): '{button_text}'")
                                        break
                            except:
                                continue
                        if found_buttons:  # Stop after finding first button
                            break
                except:
                    pass
            
            print(f"Button search completed. Found {len(found_buttons)} buttons.")
            return found_buttons
            
        except Exception as e:
            print(f"Error checking for response buttons: {e}")
            return []

    def is_moveworks_down_with_buttons(self, response_text, response_buttons):
        """Check if Moveworks is down - Enhanced with pre-fetched button detection"""
        
        response = response_text.strip()
        
        # PRIMARY CHECK: Exact error from image(1).png
        if "Error encountered while rendering this message" in response:
            return True, "DOWN: Rendering error detected"
        
        # SECONDARY CHECK: Other potential down indicators
        down_indicators = [
            "error encountered",
            "something went wrong", 
            "service unavailable",
            "temporarily unavailable",
            "unable to process",
            "system error",
            "maintenance mode",
            "service is down",
            "currently unavailable"
        ]
        
        response_lower = response.lower()
        for indicator in down_indicators:
            if indicator in response_lower:
                return True, f"DOWN: Error detected - {indicator}"
        
        # Check for Moveworks response buttons (using pre-fetched buttons)
        if response_buttons:
            button_names = [btn[1] for btn in response_buttons]
            print(f"Found {len(response_buttons)} response buttons: {button_names}")
            return False, f"UP: Bot responded with buttons - {', '.join(button_names[:2])}"
        
        # If we get substantial text response without errors or buttons
        if len(response) > 10:
            return False, f"UP: Bot responded with text - {response[:100]}..."
        
        # No response at all = DOWN
        return True, "DOWN: No response from bot"

    def is_moveworks_down(self, response_text):
        """Check if Moveworks is down - Enhanced with button detection"""
        
        response = response_text.strip()
        
        # PRIMARY CHECK: Exact error from image(1).png
        if "Error encountered while rendering this message" in response:
            return True, "DOWN: Rendering error detected"
        
        # SECONDARY CHECK: Other potential down indicators
        down_indicators = [
            "error encountered",
            "something went wrong", 
            "service unavailable",
            "temporarily unavailable",
            "unable to process",
            "system error",
            "maintenance mode",
            "service is down",
            "currently unavailable"
        ]
        
        response_lower = response.lower()
        for indicator in down_indicators:
            if indicator in response_lower:
                return True, f"DOWN: Error detected - {indicator}"
        
        # NEW: Check for Moveworks response buttons (your brilliant insight!)
        response_buttons = self.check_for_moveworks_response_buttons()
        
        if response_buttons:
            button_names = [btn[1] for btn in response_buttons]
            print(f"Found {len(response_buttons)} response buttons: {button_names}")
            return False, f"UP: Bot responded with buttons - {', '.join(button_names[:2])}"
        
        # If we get substantial text response without errors or buttons
        if len(response) > 10:
            return False, f"UP: Bot responded with text - {response[:100]}..."
        
        # No response at all = DOWN
        return True, "DOWN: No response from bot"

    def send_test_message(self):
        print("Sending test message to Moveworks...")
        
        try:
            start_time = time.time()
            
            message_selectors = [
                "[data-tid='ckeditor']",
                "[contenteditable='true']",
                "textarea",
                "[role='textbox']",
                "[aria-label*='Type a message']",
                "[placeholder*='Type a message']"
            ]
            
            message_input = None
            for selector in message_selectors:
                try:
                    message_input = WebDriverWait(self.driver, 10).until(
                        EC.element_to_be_clickable((By.CSS_SELECTOR, selector))
                    )
                    print(f"Found message input with selector: {selector}")
                    break
                except TimeoutException:
                    continue
                    
            if not message_input:
                response_time = int((time.time() - start_time) * 1000)
                return False, response_time, "Could not find message input"
            
            message_input.click()
            time.sleep(0.5)
            
            test_message = self.config["test_message"]
            print(f"Sending message: '{test_message}'")
            
            success = self.send_message_automation_method(message_input, test_message)
            
            if not success:
                print("Automation method failed, trying fallback...")
                try:
                    message_input.clear()
                    message_input.send_keys(test_message)
                    message_input.send_keys(Keys.ENTER)
                    print("Fallback method used")
                    success = True
                except Exception as e:
                    response_time = int((time.time() - start_time) * 1000)
                    return False, response_time, f"Both methods failed: {str(e)}"
            
            # Message sent successfully - no verification needed since we can see it works
                    return False, response_time, f"Both methods failed: {str(e)}"
            
            print("Waiting for Moveworks response...")
            time.sleep(3)
            
            response_time = int((time.time() - start_time) * 1000)
            
            response_text = self.get_latest_bot_response()
            
            response_buttons = self.check_for_moveworks_response_buttons()
            
            is_down, status_message = self.is_moveworks_down_with_buttons(response_text, response_buttons)
            
            print(f"Response analysis: {status_message}")
            print(f"Full response: '{response_text[:200]}...' ({len(response_text)} chars)")
            
            if is_down:
                return False, response_time, status_message
            else:
                return True, response_time, status_message
            
        except Exception as e:
            response_time = int((time.time() - start_time) * 1000)
            return False, response_time, f"Test failed: {str(e)}"

    def get_latest_bot_response(self):
        """Get the latest response from Moveworks bot"""
        try:
            # Wait a moment for response to appear
            time.sleep(2)
            
            # Look for bot response messages
            response_selectors = [
                "[data-tid='message-body']",
                ".message-body",
                "[role='log'] div",
                ".fui-ChatMessage__content",
                "[data-testid='chat-message-content']"
            ]
            
            for selector in response_selectors:
                try:
                    messages = self.driver.find_elements(By.CSS_SELECTOR, selector)
                    if messages:
                        # Get the last message (most recent)
                        latest_message = messages[-1].text.strip()
                        if latest_message and len(latest_message) > 0:
                            print(f"Bot response found: '{latest_message[:100]}...'")
                            return latest_message
                except Exception:
                    continue
            
            print("No bot response found")
            return ""
            
        except Exception as e:
            print(f"Error getting bot response: {e}")
            return ""

    def get_previous_status_from_csv(self):
        """Read the last status from CSV file for smart comparison"""
        try:
            if not os.path.exists(self.csv_file):
                return None  # No previous status
            
            with open(self.csv_file, 'r') as f:
                lines = f.readlines()
                if len(lines) <= 1:  # Only header or empty
                    return None
                
                # Get the last line (most recent status)
                last_line = lines[-1].strip()
                if last_line:
                    # CSV format: timestamp,status,response_time_ms,details
                    parts = last_line.split(',')
                    if len(parts) >= 2:
                        previous_status = parts[1].strip()
                        print(f"Previous status from CSV: {previous_status}")
                        return previous_status
                        
            return None
            
        except Exception as e:
            print(f"Error reading previous status: {e}")
            return None

    def navigate_to_teams_chat(self, chat_name):
        """Navigate to Teams chat using OPTIMIZED selectors and debugging"""
        try:
            print(f"Navigating to chat: {chat_name}")
            
            # STEP 0: Wait for chat interface to fully load
            print("⚡ FAST DEBUG: Chat interface loading...")
            time.sleep(1)  # Reduced from 3
            
            # STEP 1: Try Teams keyboard shortcut first (fastest method)
            print("🚀 FAST DEBUG: Using Ctrl+Alt+G to open global search...")
            try:
                # Import Keys for keyboard shortcuts
                from selenium.webdriver.common.keys import Keys
                from selenium.webdriver.common.action_chains import ActionChains

                # Send Ctrl+Alt+G to open global search (Teams v2 shortcut)
                actions = ActionChains(self.driver)
                actions.key_down(Keys.CONTROL).key_down(Keys.ALT).send_keys('g').key_up(Keys.ALT).key_up(Keys.CONTROL).perform()
                time.sleep(1)  # Reduced from 3 - wait for search bar to appear

                # Look for the global search input that appears at the top
                global_search_selectors = [
                    "//input[@placeholder='Type a chat or channel']",  # EXACT from trigger.png
                    "//input[contains(@placeholder, 'Type a chat')]",   # Partial match
                    "//input[@placeholder='Search (Ctrl+Alt+G)']",     # Teams v2 specific
                    "//input[@type='search']",                         # From debug output
                    "//input[contains(@placeholder, 'Search')]",       # Fallback
                    "//input[@data-tid='search-input']"                # Fallback
                ]

                search_input = None
                for i, selector in enumerate(global_search_selectors):
                    try:
                        print(f"Trying global search selector {i+1}: {selector}")
                        search_input = WebDriverWait(self.driver, 2).until(  # Reduced from 3
                            EC.element_to_be_clickable((By.XPATH, selector))
                        )
                        print(f"✅ Found global search input with selector {i+1}")
                        break
                    except TimeoutException:
                        print(f"❌ Global search selector {i+1} failed")
                        continue

                if search_input:
                    print("🎯 Global search opened successfully!")
                    # Clear and search for the chat
                    search_input.clear()
                    search_input.send_keys(chat_name)
                    time.sleep(1)  # Reduced from 3 - wait for search results

                    # Look for the person in search results
                    search_result_selectors = [
                        f"//*[contains(text(), '{chat_name}')][@role='option']",
                        f"//div[@role='option'][contains(., '{chat_name}')]",
                        f"//*[contains(text(), '{chat_name}')]//ancestor::*[@role='option']",
                        f"//li[contains(., '{chat_name}')]",  # Search results often use li elements
                        f"//*[contains(text(), '{chat_name}')]"
                    ]

                    for i, selector in enumerate(search_result_selectors):
                        try:
                            print(f"Looking for search result with selector {i+1}: {selector}")
                            result_element = WebDriverWait(self.driver, 5).until(
                                EC.element_to_be_clickable((By.XPATH, selector))
                            )
                            result_element.click()
                            print(f"✅ Clicked on search result for: {chat_name}")
                            time.sleep(3)  # Wait for chat to fully load
                            
                            # IMPORTANT: Wait for the chat interface to be ready
                            print("⏳ Waiting for chat interface to be ready...")
                            try:
                                # Wait for the message input to be available
                                WebDriverWait(self.driver, 5).until(
                                    EC.presence_of_element_located((By.XPATH, "//div[@contenteditable='true'][@data-tid='ckeditor']"))
                                )
                                print("✅ Chat interface is ready!")
                            except TimeoutException:
                                print("⚠️ Chat interface not fully loaded, but continuing...")
                            
                            return True
                        except TimeoutException:
                            print(f"❌ Search result selector {i+1} failed")
                            continue

                    print("❌ Could not find person in global search results")
                else:
                    print("❌ Could not open global search with Ctrl+Alt+G")

            except Exception as shortcut_error:
                print(f"❌ Keyboard shortcut failed: {shortcut_error}")

            # FALLBACK: Try the sidebar search method
            print("🔄 Falling back to sidebar search...")
            
            # STEP 2: Find the search input using OPTIMIZED selectors
            search_selectors = [
                # MOST COMMON: General search input in Teams
                "//input[@type='text'][contains(@placeholder, 'Search') or contains(@placeholder, 'Filter')]",
                
                # SPECIFIC: From your HTML inspection
                "//input[@data-testid='simple-collab-left-rail-activity-filter-input']",
                "//input[@placeholder='Filter by name or group name']",
                
                # BROADER: Any text input in the left sidebar
                "//div[contains(@class, 'left')]//input[@type='text']",
                "//aside//input[@type='text']",
                
                # FALLBACK: Any search-like input
                "//input[contains(@class, 'search')]",
                "//input[contains(@aria-label, 'search')]"
            ]
            
            search_input = None
            print("Trying to find search input...")
            for i, selector in enumerate(search_selectors):
                try:
                    print(f"Trying selector {i+1}: {selector}")
                    search_input = WebDriverWait(self.driver, 2).until(
                        EC.element_to_be_clickable((By.XPATH, selector))
                    )
                    print(f"✅ Found search input with selector {i+1}")
                    break
                except TimeoutException:
                    print(f"❌ Selector {i+1} failed")
                    continue
            
            if not search_input:
                print("❌ Could not find search input with any selector")
                print("🔍 DEBUG: Looking for any input elements on page...")
                
                # Debug: Show what input elements exist
                try:
                    all_inputs = self.driver.find_elements(By.XPATH, "//input")
                    print(f"Found {len(all_inputs)} input elements:")
                    for i, inp in enumerate(all_inputs[:5]):  # Show first 5
                        try:
                            placeholder = inp.get_attribute('placeholder') or 'No placeholder'
                            data_tid = inp.get_attribute('data-testid') or 'No data-testid'
                            input_type = inp.get_attribute('type') or 'No type'
                            print(f"  Input {i+1}: type='{input_type}', placeholder='{placeholder}', data-testid='{data_tid}'")
                        except:
                            print(f"  Input {i+1}: Could not get attributes")
                except Exception as debug_error:
                    print(f"Debug failed: {debug_error}")
                
                print("Trying direct chat finding...")
                return self.find_chat_directly(chat_name)
            
            # STEP 2: Clear and search for the chat
            search_input.click()
            time.sleep(0.5)
            search_input.clear()
            search_input.send_keys(chat_name)
            time.sleep(3)  # Wait for search results
            
            # STEP 3: Click on the chat from results
            chat_result_selectors = [
                f"//*[contains(text(), '{chat_name}')]",
                f"//div[contains(text(), '{chat_name}')]//ancestor::div[@role='button']",
                f"//div[contains(text(), '{chat_name}')]//ancestor::button",
                f"//*[contains(text(), '{chat_name}')]//ancestor::*[@role='listitem']",
                f"//div[@data-tid='chat-list-item'][contains(., '{chat_name}')]"
            ]
            
            chat_found = False
            for selector in chat_result_selectors:
                try:
                    chat_element = WebDriverWait(self.driver, 5).until(
                        EC.element_to_be_clickable((By.XPATH, selector))
                    )
                    chat_element.click()
                    chat_found = True
                    print(f"Successfully opened chat: {chat_name}")
                    time.sleep(2)
                    break
                except TimeoutException:
                    continue
            
            return chat_found
            
        except Exception as e:
            print(f"Error navigating to chat: {e}")
            return False

    def find_chat_directly(self, chat_name):
        """OPTIMIZED fallback method to find chat directly in the chat list"""
        try:
            print(f"Looking for '{chat_name}' directly in chat list")
            
            # Wait for chat list to load
            time.sleep(2)
            
            # OPTIMIZED: Look for chat in the sidebar using multiple strategies
            chat_list_selectors = [
                # Strategy 1: Look for the exact name in chat list items
                f"//div[@data-tid='chat-list-item']//span[contains(text(), '{chat_name}')]",
                f"//div[@data-tid='chat-list-item'][contains(., '{chat_name}')]",
                
                # Strategy 2: Look in the Chats section specifically
                f"//div[text()='Chats']//following-sibling::*//span[contains(text(), '{chat_name}')]",
                
                # Strategy 3: Look for clickable elements with the name
                f"//*[@role='button'][contains(., '{chat_name}')]",
                f"//*[@role='listitem'][contains(., '{chat_name}')]",
                
                # Strategy 4: Broader search in left sidebar
                f"//aside//span[contains(text(), '{chat_name}')]",
                f"//div[contains(@class, 'left')]//span[contains(text(), '{chat_name}')]",
                
                # Strategy 5: Fallback - any element with the name
                f"//*[contains(text(), '{chat_name}')]"
            ]
            
            for i, selector in enumerate(chat_list_selectors):
                try:
                    print(f"Trying direct chat selector {i+1}: {selector}")
                    elements = self.driver.find_elements(By.XPATH, selector)
                    
                    for element in elements:
                        if element.is_displayed():
                            try:
                                # Try to click the element or its parent
                                clickable_element = element
                                
                                # If element is not clickable, try parent elements
                                if not element.is_enabled():
                                    parent = element.find_element(By.XPATH, "..")
                                    if parent.is_enabled():
                                        clickable_element = parent
                                
                                clickable_element.click()
                                print(f"✅ Found and clicked chat: {chat_name}")
                                time.sleep(3)  # Wait for chat to load
                                return True
                                
                            except Exception as click_error:
                                print(f"Click failed for element: {click_error}")
                                continue
                                
                except Exception as selector_error:
                    print(f"❌ Selector {i+1} failed: {selector_error}")
                    continue
            
            print(f"❌ Could not find chat '{chat_name}' in any chat list")
            return False
            
        except Exception as e:
            print(f"Direct chat finding failed: {e}")
            return False

    def detect_moveworks_interface_type(self):
        """Detect which Moveworks interface we're currently in"""
        try:
            # Check for Apps layout (full-screen Moveworks)
            apps_indicators = [
                "//div[contains(@class, 'fui-FlexItem')]//div[@data-tid='ckeditor']",
                "//*[contains(text(), 'Moveworks')]//ancestor::*[contains(@class, 'fui-FlexItem')]",
                "//div[@data-tid='ckeditor']//ancestor::*[contains(@class, 'fui-FlexItem')]"
            ]
            
            for selector in apps_indicators:
                try:
                    if self.driver.find_elements(By.XPATH, selector):
                        print("Detected: Apps interface (full-screen Moveworks)")
                        return "apps"
                except:
                    continue
            
            # Check for Chat layout (sidebar visible)
            chat_indicators = [
                "//div[contains(text(), 'Rodriguez, Fabricio')]",
                "//div[contains(text(), 'Real MW Core')]",
                "//div[@data-tid='chat-list-item']",
                "//*[contains(text(), 'Chat')]//ancestor::div[contains(@class, 'sidebar')]",
                "//div[contains(@class, 'chat-list')]"
            ]
            
            for selector in chat_indicators:
                try:
                    if self.driver.find_elements(By.XPATH, selector):
                        print("Detected: Chat interface (sidebar visible)")
                        return "chat"
                except:
                    continue
            
            print("Could not determine interface type - defaulting to apps")
            return "apps"
            
        except Exception as e:
            print(f"Interface detection error: {e}")
            return "apps"

    def navigate_to_chat_from_apps(self):
        """Navigate from Apps interface to Chat interface"""
        try:
            print("Navigating from Apps to Chat interface...")
            
            # Look for Chat button in the left sidebar
            chat_selectors = [
                "//button[@aria-label='Chat']",
                "//*[@data-tid='app-bar-item-chat']",
                "//span[text()='Chat']//parent::button",
                "//*[contains(@aria-label, 'Chat')]",
                "//div[contains(text(), 'Chat')]//ancestor::button",
                "//*[contains(@class, 'app-bar')]//button[contains(., 'Chat')]"
            ]

            chat_button = None
            for selector in chat_selectors:
                try:
                    chat_button = WebDriverWait(self.driver, 3).until(
                        EC.element_to_be_clickable((By.XPATH, selector))
                    )
                    break
                except TimeoutException:
                    continue

            if chat_button:
                chat_button.click()
                print("Successfully navigated to Chat section")
                time.sleep(2)
                return True
            else:
                print("Could not find Chat button")
                return False

        except Exception as e:
            print(f"Error navigating to Chat from Apps: {e}")
            return False

    def send_teams_notification(self, current_status, details):
        """Send smart notification to Teams chat handling both interface layouts"""
        try:
            if not self.config.get('enable_teams_notifications', True):
                print("Teams notifications disabled in config")
                return True
            
            # Status change detection is now handled in run_single_check()
            # This method just sends the notification when called
            print("Sending Teams notification...")
            
            # Detect current interface type
            interface_type = self.detect_moveworks_interface_type()
            
            # Handle navigation based on interface type
            if interface_type == "apps":
                print("Currently in Apps interface - need to navigate to Chat")
                # Navigate to Chat section first
                if not self.navigate_to_chat_from_apps():
                    print("Failed to navigate from Apps to Chat")
                    return False
            
            # Navigate to the target chat
            target_chat = self.config['notification_target']
            if not self.navigate_to_teams_chat(target_chat):
                print(f"Failed to navigate to chat: {target_chat}")
                return False
            
            # CRITICAL: Wait for chat interface to be fully ready
            print("⏳ FAST DEBUG: Waiting for chat message input to be ready...")
            time.sleep(2)  # Give the chat interface time to load
            
            # Wait for message input to be available and interactable
            try:
                WebDriverWait(self.driver, 5).until(
                    EC.element_to_be_clickable((By.XPATH, "//div[@data-tid='ckeditor']"))
                )
                print("✅ Message input is ready!")
            except TimeoutException:
                print("⚠️ Message input not immediately ready, trying anyway...")
            
            # Find message input using EXACT selectors (works for both interfaces)
            message_selectors = [
                # PRIMARY: Your exact HTML selector (works for both layouts)
                "//div[@data-tid='ckeditor']",
                
                # SECONDARY: Your exact aria-label (works for both layouts)
                "//div[@aria-label='Type a message']",
                
                # TERTIARY: Combination from your HTML (works for both layouts)
                "//div[@contenteditable='true'][@role='textbox']",
                
                # FALLBACK: From automation.py (same selectors!)
                "//div[@role='textbox']",
                "//div[@contenteditable='true']"
            ]
            
            message_input = None
            for i, selector in enumerate(message_selectors):
                try:
                    elements = self.driver.find_elements(By.XPATH, selector)
                    for j, element in enumerate(elements):
                        try:
                            if element.is_displayed() and element.is_enabled():
                                # Test if element is interactable (from automation.py)
                                self.driver.execute_script("arguments[0].focus();", element)
                                time.sleep(0.1)
                                message_input = element
                                print(f"Message input found with selector {i+1}: {selector}")
                                break
                        except Exception as e:
                            continue
                    if message_input:
                        break
                except Exception as e:
                    continue
            
            if not message_input:
                print("Could not find message input")
                return False
            
            # Create the notification message
            timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            notification_message = f"Moveworks is {current_status}"
            
            # Send message using automation.py proven method
            try:
                print(f"🚀 FAST DEBUG: Sending message: '{notification_message}'")
                
                # Focus and click (automation.py method)
                self.driver.execute_script("arguments[0].focus();", message_input)
                self.driver.execute_script("arguments[0].click();", message_input)
                time.sleep(0.5)  # Increased wait for focus
                
                # Clear any existing text (automation.py method)
                message_input.send_keys(Keys.CONTROL + "a")
                message_input.send_keys(Keys.DELETE)
                time.sleep(0.2)  # Increased wait for clear
                
                # Type and send message (automation.py method)
                print("⌨️ Typing message...")
                message_input.send_keys(notification_message)
                time.sleep(0.5)  # Wait for typing to complete
                
                print("📤 Sending message with Enter...")
                message_input.send_keys(Keys.ENTER)
                time.sleep(1)  # Wait for message to send
                
                print(f"✅ Teams notification sent to '{target_chat}': {notification_message}")
                return True
                
            except Exception as e:
                print(f"Message sending failed: {e}")
                return False
            
        except Exception as e:
            print(f"Error sending Teams notification: {e}")
            return False

    def log_status(self, is_up, response_time, details):
        """Log status to CSV file"""
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        status = 'UP' if is_up else 'DOWN'
        
        with open(self.csv_file, 'a', newline='') as f:
            writer = csv.writer(f)
            writer.writerow([timestamp, status, response_time, details])
        
        print(f"Logged: {timestamp} | {status} | {response_time}ms | {details}")

    def send_alert_email(self, status, details):
        """Send email alert when status changes"""
        try:
            if not self.config.get('alert_email'):
                return
                
            subject = f"Moveworks Status Alert: {status}"
            body = f"""
Moveworks Bot Status Change Detected

Status: {status}
Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
Details: {details}

This is an automated alert from the FINRA Moveworks Monitoring System.
"""
            
            msg = MIMEMultipart()
            msg['From'] = self.config['teams_email']
            msg['To'] = self.config['alert_email']
            msg['Subject'] = subject
            
            msg.attach(MIMEText(body, 'plain'))
            
            server = smtplib.SMTP(self.config['smtp_server'], self.config['smtp_port'])
            server.starttls()
            server.login(self.config['teams_email'], self.config['teams_password'])
            server.send_message(msg)
            server.quit()
            
            print(f"Alert email sent: {status}")
            
        except Exception as e:
            print(f"Failed to send alert email: {e}")

    def run_single_check(self):
        """Run a single monitoring check"""
        print(f"Starting check at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        
        try:
            if not self.setup_headless_browser():
                return False
            
            if not self.login_to_teams():
                return False
            
            if not self.find_moveworks_bot():
                return False
            
            is_up, response_time, details = self.send_test_message()
            
            # UNIFIED STATUS LOGIC: Use CSV as single source of truth
            current_status = 'UP' if is_up else 'DOWN'
            previous_status = self.get_previous_status_from_csv()  # Read BEFORE logging new status
            
            # Log the new status AFTER reading the previous one
            self.log_status(is_up, response_time, details)
            
            # Send alert only on status change
            if previous_status != current_status:
                print(f"Status change detected: {previous_status} -> {current_status}")
                
                # Send Teams notification (primary method)
                teams_success = self.send_teams_notification(current_status, details)
                if teams_success:
                    print("Teams notification sent successfully")
                else:
                    print("Teams notification failed")
                
                # Send email alert (fallback method - will likely fail due to firewall)
                self.send_alert_email(current_status, details)
            else:
                print(f"Status unchanged ({current_status}) - no notification sent")
            
            print(f"Check completed: {current_status}")
            return True
            
        except Exception as e:
            print(f"Check failed: {e}")
            self.log_status(False, 0, f"Check failed: {str(e)}")
            return False
        finally:
            if self.driver:
                self.driver.quit()

    def run_monitoring_loop(self):
        """Main monitoring loop"""
        print("Starting FINRA Moveworks Continuous Monitoring")
        print(f"Check interval: {self.config['check_interval_hours']} hours")
        print(f"Monitoring bot: {self.config['moveworks_bot_name']}")
        print(f"Logging to: {self.csv_file}")
        print("Press Ctrl+C to stop monitoring")
        
        check_count = 0
        
        try:
            while True:
                check_count += 1
                print(f"\n--- Check #{check_count} ---")
                
                success = self.run_single_check()
                
                if success:
                    print(f"Check #{check_count} completed successfully")
                else:
                    print(f"Check #{check_count} failed")
                
                sleep_seconds = self.config['check_interval_hours'] * 3600
                next_check = datetime.now().timestamp() + sleep_seconds
                next_check_time = datetime.fromtimestamp(next_check).strftime('%Y-%m-%d %H:%M:%S')
                
                print(f"Next check scheduled for: {next_check_time}")
                print(f"Sleeping for {self.config['check_interval_hours']} hours...")
                
                time.sleep(sleep_seconds)
                
        except KeyboardInterrupt:
            print("\nMonitoring stopped by user")
        except Exception as e:
            print(f"\nMonitoring stopped due to error: {e}")
        finally:
            if self.driver:
                self.driver.quit()
            print("Monitoring session ended")


def run_resource_check_before_program():
    print("SMART RESOURCE CHECK")
    print("=" * 30)
    
    checker = SmartResourceChecker()
    
    if not checker.check_system_resources():
        print("System resources are insufficient")
        print("Proceeding with monitoring (automated mode)")
        return True
    
    print("System resources are sufficient")
    return True

if __name__ == "__main__":
    print("FINRA Moveworks Monitoring System - HYBRID VERSION")
    print("=" * 50)
    
    if not run_resource_check_before_program():
        print("Resource check failed - exiting")
        exit(1)
    
    monitor = MoveworksMonitor()
    
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == "--test":
        print("Running single test check...")
        success = monitor.run_single_check()
        if success:
            print("Test completed successfully")
        else:
            print("Test failed")
    elif len(sys.argv) > 1 and sys.argv[1] == "--login-only":
        print("Testing login only...")
        if monitor.setup_headless_browser():
            print("Browser setup successful")
            
            if monitor.login_to_teams():
                print("Login successful!")
                
                if monitor.find_moveworks_bot():
                    print("Moveworks bot found successfully!")
                else:
                    print("Could not find Moveworks bot")
            else:
                print("Login failed")
        else:
            print("Browser setup failed")
        
        if monitor.driver:
            monitor.driver.quit()
        print("Login test complete")
    else:
        print("Starting continuous monitoring...")
        print("Use --test for single check or --login-only for login test")
        monitor.run_monitoring_loop()
