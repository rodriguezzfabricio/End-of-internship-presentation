# Moveworks Monitoring Tool

**Automatically monitors the Moveworks bot in Microsoft Teams and alerts you when it's down.**

---

## Quick Start (5 Minutes)

### Step 1: Install Prerequisites (If Needed)

**Check if you have Python:**
1. Press `Win + R`, type `cmd`, press Enter
2. Try these commands (one should work):
   - Type `python --version` and press Enter
   - If that doesn't work, try `py --version` and press Enter
3. If you see a version number (like `Python 3.11.0`), you're good to go!

**Note:** Don't worry which command works - our setup script automatically detects both

**If Python is missing:**
- **Option 1:** FINRA Employee Portal
  - Go to the FINRA Employee Portal
  - Search for "Python"
  - Install Python 3.8 or higher
  - ![Python Employee Portal](images/python%20employee%20portal.png)

- **Option 2:** Software Center
  - Open Software Center on your computer
  - Search for "Python"
  - Install the latest version
  - ![Python Software Center](images/python%20software%20center.png)

**ChromeDriver (Usually automatic, but if needed):**
- Go to FINRA Employee Portal
- Search for "Chrome Web Driver"
- Install the latest version
- ![ChromeDriver Employee Portal](images/Chrome%20Web%20Driver%20employee%20portal.png)

### Step 2: Run the Setup

1. **Extract this folder** to any location on your computer (e.g., `C:\MoveworksMonitoring`)
2. **Double-click `EASY_SETUP.bat`**
3. **Wait for it to complete** (it will install everything automatically)
4. **Press any key** when it says "Setup Complete!"

### Step 3: Configure Your Credentials

1. **Open `config.json`** (it was created from the template)
2. **Edit these fields with your information:**
   ```json
   {
       "teams_email": "your.email@finra.org",
       "teams_password": "YourPassword123"
   }
   ```
3. **Save the file**

### Step 4: Test It Works

1. **Double-click `start_monitoring.bat`**
2. **You'll see a black command prompt window open** - this is normal for testing
3. **Wait 2-3 minutes** for it to complete one full check
4. **You'll see messages like:**
   - "Found Moveworks in Teams"
   - "Sending test message: health check"
   - "Moveworks is UP" 
   - "Sleeping for 2 hours..."
5. **Check for these new files:**
   - `startup_log.txt` - Shows the script started successfully
   - `moveworks_status.csv` - Will be created with monitoring results

**IMPORTANT: You can close this command prompt window after the first successful check!**

### Step 5: Understanding How It Works

#### **Manual Testing (What You Just Did):**
- Shows a visible command prompt window
- Displays all the monitoring activity
- Good for testing and troubleshooting
- You can close this window anytime

####  **Automatic Operation (After Restart):**
- **Completely invisible** - no windows, no browser pop-ups
- **No taskbar icons** - runs silently in background
- **No interruptions** - you won't even know it's running
- **Checks every 2 hours** automatically
- **Sends alerts to Real MW Core group chat** if there are problems

####  **To Switch to Automatic Mode:**
1. **Close the test window** (if still open)
2. **Restart your computer**
3. **Wait 5 minutes after login**
4. **Check `startup_log.txt`** - should show automatic startup
5. **That's it!** - monitoring now runs invisibly forever

### Step 6: You're Done! 

The monitoring will now:
- ✅ Start automatically when Windows boots
- ✅ Check Moveworks every 2 hours
- ✅ Send alerts to Real MW Core group chat if there are issues
- ✅ Log all results to `moveworks_status.csv`
- ✅ Run completely invisibly in the background

---

## 📋 System Requirements

- **Windows 10/11**
- **Python 3.8 or higher** (available in Employee Portal/Software Center)
- **Microsoft Teams access**
- **Internet connection**
- **Chrome or Edge browser**

---

## 🔧 Troubleshooting

### "Can I close the command prompt window?"
**YES!** If you see a black command prompt window after running `start_monitoring.bat`:
- This is just for testing/debugging
- You can close it anytime after the first successful check
- The automatic version (after restart) runs completely invisibly

### "Will I see browser windows opening?"
**NO!** When running automatically:
- No browser windows will appear
- No command prompts will show
- No taskbar icons will appear
- Everything runs silently in the background

### "How do I know it's working?"
Check these files:
- `startup_log.txt` - Shows when the script starts/stops
- `moveworks_status.csv` - Shows all monitoring results
- You'll get email alerts if Moveworks goes down

### "Python is not installed"
- Install Python from Employee Portal or Software Center (see Step 1 above)
- Make sure to restart Command Prompt after installation

### "Package installation failed"
- This is usually due to FINRA's firewall
- The script automatically handles Finra's corporate settings

### "Config.json not found"
- Make sure you ran `EASY_SETUP.bat` first
- If the file is missing, copy `config_template.json` to `config.json`

### "Teams login failed"
- Double-check your email and password in `config.json`
- Make sure you can log into Teams manually with the same credentials
- Try using an app password instead of your main password

### "ChromeDriver not found"
- The script tries to download it automatically
- If that fails, install from Employee Portal (see Step 1 above)

### Script doesn't start automatically
- Make sure you ran `EASY_SETUP.bat` as Administrator
- If not, run `setup_manual_startup.bat` for alternative methods

---

## 📊 Understanding the Results

### Log Files
- **`startup_log.txt`** - Shows when the script starts/stops
- **`moveworks_status.csv`** - Contains all monitoring results with timestamps

### CSV Columns
- **Timestamp** - When the check was performed
- **Status** - "Online" or "Offline"
- **Response_Time** - How long Moveworks took to respond
- **Message** - Details about the check



## ⚙️ Customization

### Change Check Frequency
Edit `config.json`:
```json
"check_interval_hours": 1
```
(Checks every hour instead of every 2 hours)

### Change Test Message
Edit `config.json`:
```json
"test_message": "system status check"
```

---

##  Security Notes

- **Never share your `config.json` file** - it contains your password
- **The `config_template.json` is safe to share**
- **Consider using an app password** instead of your main Teams password
- **The script runs completely invisibly** - no windows will pop up during monitoring

---

## How to Stop the Monitoring

**Need to stop the monitoring? Here are your options:**

### Option 1: Permanently Stop (Recommended)
**This completely removes the automatic monitoring:**

1. **Press `Win + R`** (Windows key + R)
2. **Type `cmd`** and press **Ctrl + Shift + Enter** (this opens as Administrator)
3. **Copy and paste this command:**
   ```
   schtasks /delete /tn "Moveworks Monitoring" /f
   ```
4. **Press Enter**
5. **Done!** The monitoring will never start again

### Option 2: Stop Using Windows Interface
**If you prefer clicking instead of typing commands:**

1. **Press `Win + R`**, type `taskschd.msc`, press Enter
2. **Look for "Moveworks Monitoring"** in the task list
3. **Right-click it** and select **"Delete"**
4. **Click "Yes"** to confirm
5. **Done!** Monitoring is permanently stopped

### Option 3: Temporarily Stop (Just This Session)
**Stops monitoring now, but it will restart when you reboot:**

1. **Press `Ctrl + Shift + Esc`** (opens Task Manager)
2. **Click "More details"** if needed
3. **Look for `python.exe`** in the process list
4. **Right-click the python.exe** that's running monitoring
5. **Click "End task"**

**Note:** This only stops it temporarily - it will restart when you reboot your computer.

### Option 4: Pause Monitoring (Keep Setup, Don't Run)
**Keeps everything installed but stops it from running:**

1. **Press `Win + R`**, type `cmd`, press **Ctrl + Shift + Enter**
2. **Copy and paste this command:**
   ```
   schtasks /change /tn "Moveworks Monitoring" /disable
   ```
3. **Press Enter**

**To re-enable later:**
```
schtasks /change /tn "Moveworks Monitoring" /enable
```

### How to Check if It's Really Stopped

**Method 1 - Check Task Scheduler:**
1. Press `Win + R`, type `taskschd.msc`, press Enter
2. If you don't see "Moveworks Monitoring" in the list, it's stopped

**Method 2 - Command Line Check:**
1. Press `Win + R`, type `cmd`, press Enter
2. Type: `schtasks /query /tn "Moveworks Monitoring"`
3. If you see "ERROR: The system cannot find the file specified" - it's successfully stopped!

### What Happens When You Stop It?

- **No more automatic monitoring** - Moveworks won't be checked anymore
- **No more background processes** - Nothing running invisibly
- **No more alerts** - You won't get notifications about Moveworks status
- **Files remain** - All your setup files stay in place (in case you want to restart later)
- **Easy to restart** - Just run `EASY_SETUP.bat` again if you change your mind

### Most Common Choice: Option 1
**99% of users should use Option 1** - it's the cleanest way to permanently stop everything.

---

##  Getting Help

### Check These First:
1. **Log files** - `startup_log.txt` and `moveworks_status.csv`
2. **Test manually** - Run `start_monitoring.bat` and watch for errors
3. **Verify credentials** - Make sure you can log into Teams manually

### Common Solutions:
- **Restart your computer** if auto-startup isn't working
- **Run as Administrator** if you get permission errors
- **Check your internet connection** if monitoring fails
- **Contact IT** for firewall/proxy issues


## 📁 File Descriptions

| File | Purpose |
|------|---------|
| `EASY_SETUP.bat` | One-click setup script |
| `start_monitoring.bat` | Runs the monitoring script |
| `monitoring_hybrid.py` | Main monitoring program |
| `config.json` | Your personal settings (created during setup) |
| `config_template.json` | Template for configuration |
| `requirements.txt` | List of required Python packages |
| `setup_manual_startup.bat` | Alternative startup setup |



